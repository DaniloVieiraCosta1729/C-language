#include <stdio.h>

int main(int argc, char const *argv[])
{
    float irracional = 5.44;

    printf("%.4f\n", irracional);
    printf("%.8f\n", irracional);
    return 0;
}
