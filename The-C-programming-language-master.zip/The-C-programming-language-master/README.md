Coleção de arquivos gerados durante o estudo do livro "The C programming language".
