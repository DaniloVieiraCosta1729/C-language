#include <stdio.h>

int main()
{
    char c = getchar();

    printf("Tecla digitada: %d\n", c);

    putchar(c);
    
    return 0;
}