#include <stdio.h>

int main()
{
    printf("Hello, World.");
    printf("\nHello, \tC.\n Como posso colocar \"aspas\" em uma cadeia de caracteres em C?");
    return 0;
}